<link rel="shortcut icon" href="logo.png" type="image/x-icon">

# Welcome to BlackEdit!
## BlackEdit Editor: A Free and Powerful-WYSWYG-Editor

<p><img src="./logo.png" alt="BlackEdit" height="180" align='center'/></p>

The **BlackEdit** is an open source, free to use and powerful **WYSIWYG** editor with all the modern features builtIn.

#Try 
1. [BlackEdit v4 Cryo](https://raj457036.github.io/BlackEdit/v4/)
2. [BlackEdit V3 Beta](https://raj457036.github.io/BlackEdit/v3/)
3. [BlackEdit V2 Alpha](https://raj457036.github.io/BlackEdit/v2/)

The document is under construction...



You can use this editor anywhere you want without any restriction. just if you want then give me a small credit.
thank you any suggestion is welcome.
