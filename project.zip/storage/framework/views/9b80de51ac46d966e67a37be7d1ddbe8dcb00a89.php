<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" action="<?php echo e(route('general.setting.update')); ?>" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="card ">
                            <div class="card-header card-header-primary">
                                <h4 class="card-title"><?php echo e(__('General Settings')); ?></h4>
                                <p class="card-category"><?php echo e(__('Basic Settings')); ?></p>
                            </div>
                            <div class="card-body ">
                                <?php if(session('status')): ?>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                    <i class="material-icons">close</i>
                                                </button>
                                                <span><?php echo e(session('status')); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php
                                    $data=\App\Models\GenaralSettings::all()->first();
                                ?>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Phone1</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="phone1" id="input-name" type="text" placeholder="Phone1" value="<?php echo e(old('Phone1', $data->phone1)); ?>" required="true" aria-required="true"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row"    >
                                    <label class="col-sm-2 col-form-label">Phone2</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="phone2" id="input-name" type="text" placeholder="Phone2" value="<?php echo e(old('Phone2', $data->phone2)); ?>" required="true" aria-required="true"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Email1</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="email1" id="input-email" type="email" placeholder="Email1" value="<?php echo e(old('email1', $data->email1)); ?>" required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Email2</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="email2" id="input-email" type="email" placeholder="Email2" value="<?php echo e(old('email2', $data->email2)); ?>" required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Address1</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="address1" id="input-email" type="text" placeholder="Adddress1" value="<?php echo e(old('address1', $data->address1)); ?>" required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label">Address2</label>
                                    <div class="col-sm-7">
                                        <div class="form-group">
                                            <input class="form-control" name="address2" id="input-email" type="text" placeholder="Address2" value="<?php echo e(old('address2', $data->address2)); ?>" required />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label">WhyUS?</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea class="required form-control" id="whyus" name="why_us" rows="6" cols="30" required="true"><?php echo e($data->why_us); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label">Work Ethics</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea class="required form-control" id="work_ethics" name="work_ethics" rows="6" cols="30" required="true"><?php echo e($data->work_ethics); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                <div class="row">
                                        <label class="col-sm-2 col-form-label">Location</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea class="required form-control" id="location" name="location" rows="6" cols="30" required="true"><?php echo e($data->location); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">About US</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea class="required form-control" id="about_us" name="location" rows="6" cols="30" required="true"><?php echo e($data->about_us); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Start Now Title</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">

                                                <input type="text" class="form-control" id="start_now_title" name="start_now_title" value="<?php echo e(old('start_now_title',$data->start_now_title)); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">Start now details</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <textarea class="required form-control" id="start_now_details" name="start_now_details" rows="6" cols="30" required="true"><?php echo e($data->start_now_details); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="col-sm-2 col-form-label">statistics</label>
                                        <div class="col-sm-7">
                                            <div class="form-group">
                                                <input placeholder="clients" class="form-control" type="number" name="clients" id="clients" value="<?php echo e(old('clients',$data->clients)); ?>">
                                                <input placeholder="branches" class="form-control" type="number" name="branches" id="branches" value="<?php echo e(old('clients',$data->branches)); ?>">
                                                <input placeholder="employee" class="form-control" type="number" name="employee" id="employee" value="<?php echo e(old('clients',$data->employee)); ?>">
                                                <input placeholder="cities" class="form-control" type="number" name="cities" id="cities" value="<?php echo e(old('clients',$data->cities)); ?>">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="card-footer ml-auto mr-auto">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'settings', 'titlePage' => __('Settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\backend\generalsetting\index.blade.php ENDPATH**/ ?>