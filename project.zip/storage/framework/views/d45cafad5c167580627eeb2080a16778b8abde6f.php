<?php $__env->startSection('content'); ?>
    <section id="page-title" class="bg-transparent">

        <div class="container clearfix">
            <h2><?php echo $data->title; ?></h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo $data->title; ?></li>
            </ol>
        </div>

    </section><!-- #page-title end -->

    <!-- Page Title
    ============================================= -->
    <section id="content">
        <div class="content-wrap">
            <div class="container clearfix">

                <div class="row clearfix">
                    <div class="col-lg-6">
                        <div class="heading-block border-bottom-0 bottommargin-sm">
                            <h3><?php echo $data->title; ?></h3>
                            <span> <?php echo $data->description; ?> </span>
                        </div>
                        <p><?php echo $data->long_description; ?></p>

                    </div>

                    <div class="col-lg-6">
                        <div class="fslider flex-thumb-grid grid-6" data-pagi="false" data-arrows="false" data-thumbs="true">
                            <div class="flexslider">
                                <div class="slider-wrap">
                                    <div class="slide" data-thumb="demos/construction/images/gallery/thumbs/1.jpg">
                                        <img src="<?php echo e(asset('assets/demos/construction/images/Portfolio/'.$data->thumbnail)); ?>" alt="Image">
                                        <div class="bg-overlay">
                                            <div class="bg-overlay-content justify-content-start align-items-end">
                                                <div class="h4 font-weight-light bg-light text-dark px-3 py-2"><?php echo e($data->title); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a href="<?php echo e(route('request.quote')); ?>" class="button button-3d border-bottom-0 button-full center text-right font-weight-light font-primary topmargin footer-stick" style="font-size: 26px;">
                <div class="container clearfix">
                    Would you like to Build your Dream Home with Us? <strong>Request A Quote</strong> <i class="icon-angle-right" style="top:3px;"></i>
                </div>
            </a>

        </div>
    </section><!-- #content end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\backend\generalsetting\portfolio-details.blade.php ENDPATH**/ ?>