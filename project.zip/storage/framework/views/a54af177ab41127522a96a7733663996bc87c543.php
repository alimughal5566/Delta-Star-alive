<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="stretched">

<!-- Document Wrapper
============================================= -->
<div id="wrapper" class="clearfix">

    <!-- Top Bar
    ============================================= -->
<?php echo $__env->make('frontend.layout.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- #top-bar end -->

    <!-- Header
    ============================================= -->

<?php echo $__env->make('frontend.layout.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- Content
    ============================================= -->
<?php echo $__env->yieldContent('content'); ?>

<!-- Footer
    ============================================= -->
    <!-- #footer end -->
    <?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><!-- #wrapper end -->
<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>
<!-- JavaScripts
============================================= -->
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
<!-- Footer Scripts
============================================= -->
<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\frontend\layout\app.blade.php ENDPATH**/ ?>