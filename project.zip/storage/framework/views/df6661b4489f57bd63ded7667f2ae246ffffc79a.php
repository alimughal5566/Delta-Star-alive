<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <section id="page-title" class="bg-transparent">

        <div class="container clearfix">
            <h1> Our Services</h1>
            
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Services</li>
            </ol>
        </div>

    </section>

    <!-- what we do-->
    <?php if($data->count() > 0): ?>
        <div class="main_whatwe cunstom_weDo text-center">
            <h1 class="center whatweDo ls1">What We Do:</h1>
            <h3>Exclusive Service</h3>
            <p>We provide all kinds of construction and building services and we are always glad to resolve nonstandard and unique tasks. We always take challenges and bring them to a conclusion.</p>
        </div>

        <div class="container clearfix">

            <div class="row set_height_main_ciustom justify-content-center col-mb-50">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $whatwe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-lg-4" data-aos="fade-up">
                        <div class="feature-box media-box">
                            <div class="fbox-media">
                                <a href="<?php echo e(route('whatwedo.Details',[$whatwe->id])); ?>"><img class="rounded" src="<?php echo e(asset('assets/demos/construction/images/whatwedo/'.$whatwe->thumbnail)); ?>" alt="Why choose Us?"></a>
                            </div>
                            <div class="fbox-content px-0">
                                <h3><?php echo $whatwe->title; ?> <span class="subtitle"><?php echo $whatwe->description; ?> </span></h3>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="qoute_msg_block">
                <a href="<?php echo e(route('request.quote')); ?>" class="button button-3d border-bottom-0 button-full center text-right font-weight-light font-primary topmargin footer-stick" style="font-size: 26px;">
                <div class="container clearfix">
                    Would you like to Build your Dream Home with Us? <strong>Request A Quote</strong> <i class="icon-angle-right" style="top:3px;"></i>
                </div>
            </a>
            </div>
        </div>
    <?php endif; ?>


    <section class="progress_section">
        <div class="container">
            <div class="main_progress">
                <div class="main_text_skill text-center mt-5">
                    <h2>Our Skills</h2>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="main_start_p">
                            <p>Label</p>
                           <div class="progress">
                              <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="main_start_p">
                            <p>Label</p>
                           <div class="progress">
                              <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="50">100</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="main_start_p">
                            <p>Label</p>
                           <div class="progress">
                              <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="main_start_p">
                            <p>Label</p>
                           <div class="progress">
                              <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <!--what we do end-->



    <script>
        var delay = 500;
$(".progress-bar").each(function(i){
    $(this).delay( delay*i ).animate( { width: $(this).attr('aria-valuenow') + '%' }, delay );

    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: delay,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now)+'%');
        }
    });
});
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\frontend\all_services.blade.php ENDPATH**/ ?>