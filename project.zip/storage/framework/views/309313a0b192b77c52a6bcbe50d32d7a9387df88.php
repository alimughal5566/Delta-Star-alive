<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="SemiColonWeb" />

    <!-- Stylesheets
    ============================================= -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700|Roboto:300,400,500,700&display=swap" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper.css')); ?>" type="text/css" />

    <!-- Construction Demo Specific Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/demos/construction/construction.css')); ?>" type="text/css" />
    <!-- / -->

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dark.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-icons.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" type="text/css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/demos/construction/css/fonts.css')); ?>" type="text/css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" type="text/css" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>?color=F18052" type="text/css" />

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>


    <!-- Document Title
    ============================================= -->
    <title>Construction | DeltaStar</title>

</head>
<?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\frontend\layout\header.blade.php ENDPATH**/ ?>