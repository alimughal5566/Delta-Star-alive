<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="http://deltastar.ae" class="simple-text logo-normal">
      <?php echo e(__('Delta Star')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Dashboard')); ?></p>
        </a>
      </li>































































        <li class="nav-item<?php echo e($activePage == 'slider' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('homepage.slider')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('Home Page Slider')); ?></p>
            </a>
        </li>
        <li class="nav-item<?php echo e($activePage == 'secondslider' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.second.slider')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('Home Second Slider')); ?></p>
            </a>
        </li>
        <li class="nav-item<?php echo e($activePage == 'whatwedo' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.whatwedo')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('What We Do')); ?></p>
            </a>
        </li>
        <li class="nav-item<?php echo e($activePage == 'portfolio' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.portfolio')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('Projects')); ?></p>
            </a>
        </li>
        <li class="nav-item<?php echo e($activePage == 'addfeatures' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('home.features')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('Features')); ?></p>
            </a>
        </li>
        <li class="nav-item<?php echo e($activePage == 'settings' ? ' active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('general.setting')); ?>">
                <i class="material-icons">language</i>
                <p><?php echo e(__('General Settings')); ?></p>
            </a>
        </li>

    </ul>
  </div>
</div>
<?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\layouts\navbars\sidebar.blade.php ENDPATH**/ ?>