<footer class="footer">
    <div class="container">
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons">favorite</i> by
        <a href="http://www.deltastar.ae" target="_blank">Deltastar</a> </div>
    </div>
</footer>
<?php /**PATH C:\Users\HP\Downloads\mynewproj\project\resources\views\layouts\footers\guest.blade.php ENDPATH**/ ?>