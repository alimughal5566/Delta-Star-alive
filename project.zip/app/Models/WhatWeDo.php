<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class WhatWeDo extends Model
{
    protected $guarded=[''];
}
